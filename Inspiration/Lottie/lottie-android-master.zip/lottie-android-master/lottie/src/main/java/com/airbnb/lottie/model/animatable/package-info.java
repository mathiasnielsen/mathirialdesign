@RestrictTo(LIBRARY)
package com.airbnb.lottie.model.animatable;

import android.support.annotation.RestrictTo;

import static android.support.annotation.RestrictTo.Scope.LIBRARY;