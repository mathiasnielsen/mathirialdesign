@RestrictTo(LIBRARY)
package com.airbnb.lottie.model.layer;

import android.support.annotation.RestrictTo;

import static android.support.annotation.RestrictTo.Scope.LIBRARY;