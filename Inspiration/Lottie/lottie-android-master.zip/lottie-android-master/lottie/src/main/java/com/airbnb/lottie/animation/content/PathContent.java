package com.airbnb.lottie.animation.content;

import android.graphics.Path;

import com.airbnb.lottie.animation.content.Content;

interface PathContent extends Content {
  Path getPath();
}
